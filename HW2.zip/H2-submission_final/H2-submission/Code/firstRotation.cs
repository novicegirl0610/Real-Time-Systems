﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class RotatePos : Operations, TaskInterface
{
    public bool rotated = false, firstRotation = false, secondRotation = false;
    public bool doneRotating = false, distanceReached = false;
    private DateTime start;

    public void Execute(DeviceRegistry devices) {
        if(this.doneRotating == false){
            if(this.firstRotation == false){
                start = DateTime.Now;
                float angle = devices.compass[0];
                if(angle < 0.0f){
                    angle = -180.0f - angle;
                }else{
                    angle = 180.0f - angle;
                }
                devices.steeringControl[0] = 1;
                devices.steeringControl[1] = angle;
                this.firstRotation = true;
            }
            else if(this.distanceReached == false){
                float backLidar = devices.lidar[8];
                if(backLidar > 7.0f){
                    slowDown(devices);
                    stop(devices);
                    this.distanceReached = true;
                }
                else{
                    moveForward(devices);
                }
            }
            else if(this.secondRotation == false){
                turnLeft(devices);
                this.secondRotation = true;
            }
            else{
                overrideSteering(devices);
                this.doneRotating = true;
                this.distanceReached = false;
                this.firstRotation = false;
                TimeSpan time = DateTime.Now - start;
                Debug.Log("First Rotation");
                Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
            }
        }

        
    }
}
