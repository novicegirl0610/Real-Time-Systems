using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class MoveAlongCenter : Operations, TaskInterface
{
    public bool alongTheCenter = false, parkAtLeft = false, parkAtRight = false, carTurned = false, steeringDefault = false;
    private float prevAngle = 0.0f;
    private int angleChangeCount = 0, loopCount = 0;
    private DateTime start;
    public void Execute(DeviceRegistry devices) {
        
        float angle = devices.compass[0];
        if(angle != prevAngle){
            prevAngle = angle;
            angleChangeCount++;
        }
        if(angleChangeCount == 4 || angleChangeCount == 7){
            this.prevAngle = 0.0f;
            this.alongTheCenter = true;
            start = DateTime.Now;
        }

        if(!isWall(devices) && this.alongTheCenter && !this.parkAtLeft && !this.parkAtRight){
            moveForward(devices);
            float rightLidar = devices.lidar[4];
            float leftLidar = devices.lidar[12];
            if(rightLidar != leftLidar && (rightLidar > 7.0f && rightLidar <= 10.0f || leftLidar > 7.0f && leftLidar <= 10.0f)){
                slowDown(devices);
                stop(devices);
                if(leftLidar > 7.0f && leftLidar <= 10.0f){
                    this.parkAtLeft = true;
                }
                else{
                    this.parkAtRight = true;
                }
                moveCameraDown(devices);
            }
        }
        else{
            alongTheCenter = false;
            if(isWall(devices)){
                TimeSpan time = DateTime.Now - start;
                Debug.Log("Move Along Center- Wall Detected");
                Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
            }
            
        }

        if(this.parkAtLeft){
            if(this.loopCount < 4){
                this.loopCount++;
            }
            else{
                if (this.carTurned == false){
                    turnLeft(devices);
                    this.carTurned = true;
                }
                else if (this.steeringDefault == false){
                    overrideSteering(devices);
                    this.steeringDefault = true;
                }
                else{
                    moveForward(devices);
                    if(isCarInSpot(devices)){
                        slowDown(devices);
                        stop(devices);
                        
                        this.parkAtLeft = false;
                        this.carTurned = false;
                        this.steeringDefault = false;
                        this.loopCount = 0;
                        TimeSpan time = DateTime.Now - start;
                        Debug.Log("Move Along Center- Parking Left");
                        Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
                    }
                }
            }
        }
        if(this.parkAtRight){
            if(loopCount < 4){
                this.loopCount++;
            }
            else{
                if (this.carTurned == false){
                    turnRight(devices);
                    this.carTurned = true;
                }
                else if (this.steeringDefault == false){
                    overrideSteering(devices);
                    this.steeringDefault = true;
                }
                else{
                    moveForward(devices);
                    if(isCarInSpot(devices)){
                        slowDown(devices);
                        stop(devices);
                        
                        this.parkAtRight = false;
                        this.carTurned = false;
                        this.steeringDefault = false;
                        this.loopCount = 0;
                        TimeSpan time = DateTime.Now - start;
                        Debug.Log("Move Along Center- Parking Right");
                        Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
                    }
                }
            }
        }
        
    }
}
