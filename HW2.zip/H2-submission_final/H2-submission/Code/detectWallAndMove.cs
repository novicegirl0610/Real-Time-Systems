using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class DetectWallAndMove : Operations, TaskInterface
{
    public bool startRotation = false, carTurned = false, steeringReset = false, carStop = false, detectedTwoCars = false;

    public bool prevTurnedRight = false, secondRightTurn = false, secondRightSteering = false;

    private int carCount = 0, loopCount = 0, totalChange = 0;

    private float prevRightLidar = 0.0f, prevLeftLidar = 0.0f;
    private DateTime start;
    public void Execute(DeviceRegistry devices) {
        
        
        if ((isWall(devices) || this.startRotation)){
            this.startRotation = true;
            if(this.carStop == false){
                start = DateTime.Now;
                slowDown(devices);
                stop(devices);
                this.carStop = true;
                this.carCount = 0;    
            }
            else if(this.carTurned == false){
                if(this.prevTurnedRight == false){
                    turnRight(devices);
                    this.prevTurnedRight = true;
                }
                else{
                    turnLeft(devices);
                    this.prevTurnedRight = false;
                }
                this.carTurned = true;
            }
            else if(this.steeringReset == false){
                this.steeringReset = true;
                overrideSteering(devices);
            }
            else if(this.detectedTwoCars == false){
                moveForward(devices);
                float rightLidar = devices.lidar[4];
                float leftLidar = devices.lidar[12];
                if(rightLidar != 10.0f && prevRightLidar == 10.0f && prevTurnedRight){
                    carCount++;
                }

                if(leftLidar != 10.0f && prevLeftLidar == 10.0f && !prevTurnedRight){
                    carCount++;
                }
                prevRightLidar = rightLidar;
                prevLeftLidar = leftLidar;
                if(carCount >= 2){
                    loopCount++;
                    if (loopCount % 25 == 0 && this.totalChange < 2){
                        slowDown(devices);
                        stop(devices);
                        this.detectedTwoCars = true;
                        this.loopCount = 0;
                        
                    }
                    else if(loopCount % 18 == 0 && this.totalChange == 2){
                        slowDown(devices);
                        stop(devices);
                        this.detectedTwoCars = true;
                        this.loopCount = 0;
                    }
                }
                
            }
            else if(this.secondRightTurn == false){
                if(prevTurnedRight){
                    turnRight(devices);
                }
                else{
                    turnLeft(devices);
                }
                this.secondRightTurn = true;
            }
            else if(this.secondRightSteering == false){
                overrideSteering(devices);
                this.secondRightSteering = true;
            }
            else{
                this.startRotation = false;
                this.carStop = false;
                this.carTurned = false;
                this.steeringReset = false;
                this.detectedTwoCars = false;
                this.secondRightTurn = false;
                this.secondRightSteering = false;
                this.carCount = 0;
                this.totalChange++;
                TimeSpan time = DateTime.Now - start;
                Debug.Log("Detect Wall And Move");
                Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
            }
            
        }
        
        
        

        
    }
}
