using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Operations
{
    private int[] blueCar = new int[]{0, 124, 255};
    private int[] greenCar = new int[]{0, 255, 27};
    private int[] purpleCar = new int[]{172, 0, 255};
    private int[] greyCar = new int[]{192, 192, 192};
    private int[] brownCar = new int[]{101, 33, 0};
    private int[] walls = new int[]{255, 244, 0};
    private int[] shadowWalls = new int[]{255, 243, 0};
    
    public void moveForward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 4.0f;
    }

    public void moveBackward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = -4.0f;
    }

    public void slowDown(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 0f;
    }

    public void turnLeft(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = -90.0f;
    }

    public void turnRight(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = 90.0f;
    }

    public void overrideSteering(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = 0f;
    }

    public void stop(DeviceRegistry devices){
        devices.brakeControl[0] = 1f;
        devices.brakeControl[1] = 2f;
    }

    public void moveCameraDown(DeviceRegistry devices){
        devices.cameraControl[0] = 1f;
        devices.cameraControl[1] = -10.0f;
    }
    public void moveCameraUp(DeviceRegistry devices){
        devices.cameraControl[0] = 1f;
        devices.cameraControl[1] = 10.0f;
    }

    public bool isCarInSpot(DeviceRegistry devices){
        
        for (int i = 3; i < 7; i++){
            if (devices.pixels[i, 7, 0] == blueCar[0] && devices.pixels[i, 7, 1] == blueCar[1] && devices.pixels[i, 7, 2] == blueCar[2]||
                devices.pixels[i, 7, 0] == greenCar[0] && devices.pixels[i, 7, 1] == greenCar[1] && devices.pixels[i, 7, 2] == greenCar[2]||
                devices.pixels[i, 7, 0] == purpleCar[0] && devices.pixels[i, 7, 1] == purpleCar[1] && devices.pixels[i, 7, 2] == purpleCar[2]||
                devices.pixels[i, 7, 0] == greyCar[0] && devices.pixels[i, 7, 1] == greyCar[1] && devices.pixels[i, 7, 2] == greyCar[2]||
                devices.pixels[i, 7, 0] == brownCar[0] && devices.pixels[i, 7, 1] == brownCar[1] && devices.pixels[i, 7, 2] == brownCar[2]){
                return true;
            }
        }
        return false;
    }

    public bool isWall(DeviceRegistry devices){
        for(int i = 3; i < 7; i++){
            if (devices.pixels[i, 7, 0] == walls[0] && devices.pixels[i, 7, 1] == walls[1] && devices.pixels[i, 7, 2] == walls[2]){
                return true;
            }
            if(devices.pixels[i, 7, 0] == shadowWalls[0] && devices.pixels[i, 7, 1] == shadowWalls[1] && devices.pixels[i, 7, 2] == shadowWalls[2]){
                return true;
            }
        }
        return false;
    }

    
}
