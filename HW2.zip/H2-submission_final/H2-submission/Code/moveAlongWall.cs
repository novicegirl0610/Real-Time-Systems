using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class MoveAlongWall : Operations, TaskInterface
{
    public bool spotDetectedInBetween = false, carTurned = false, steeringDefault = false;

    public bool onTheSpot =false, loopFinish = false, alongTheWall = false; 
    public float currMinDist = 0.0f, prevAngle = 0.0f;
    private int angleChangeCount = 0, loopCount = 0;
    private DateTime start;

    public void Execute(DeviceRegistry devices) {
        float angle = devices.compass[0];
        
        if(angle != prevAngle){
            prevAngle = angle;
            angleChangeCount++;
        }
        if((angleChangeCount == 2 || angleChangeCount == 8)&& this.alongTheWall == false && !isWall(devices)){
            this.alongTheWall = true;
            start = DateTime.Now;
        }
        
        if(this.alongTheWall && this.spotDetectedInBetween == false  && this.onTheSpot == false){
            if(!isWall(devices)){
                this.moveForward(devices);

                float right_lidar = devices.lidar[4];

                if(right_lidar != 10.0f){
                    if(this.currMinDist == 0.0f){
                        this.currMinDist = right_lidar;
                        
                    }
                    else if(right_lidar > this.currMinDist){
                        slowDown(devices);
                        stop(devices);
                        this.onTheSpot = true;
                    }
                    else if (Math.Abs(right_lidar - this.currMinDist) > 0.01){
                        slowDown(devices);
                        stop(devices);
                        this.spotDetectedInBetween = true;
                    }
                }

            }
        
            else{
                this.alongTheWall = false;
                this.currMinDist = 0.0f;
                TimeSpan time = DateTime.Now - start;
                Debug.Log("Move Along Wall- Wall Detected");
                Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
            }
        }

        if(this.spotDetectedInBetween || this.onTheSpot){
            if(this.onTheSpot == false && this.loopFinish == false){
                moveBackward(devices);
            }
            if(this.loopCount < 8 && this.onTheSpot == false){
                this.loopCount++;
            }
            else if (this.loopCount < 3 && this.onTheSpot){
                this.loopCount++;
            }
            else{
                this.loopFinish = true;
                if(this.carTurned == false){
                    turnRight(devices);
                    this.carTurned = true;
                }
                else if(this.steeringDefault == false){
                    overrideSteering(devices);
                    this.steeringDefault = true;
                }
                else{
                    if(isCarInSpot(devices)){
                        slowDown(devices);
                        stop(devices);
                        
                        this.spotDetectedInBetween = false;
                        this.carTurned = false;
                        this.steeringDefault = false;
                        this.alongTheWall = false;
                        this.loopCount = 0;
                        this.onTheSpot = false;

                        TimeSpan time = DateTime.Now - start;
                        Debug.Log("Move Along Wall- Parking");
                        Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
                    }
                    else{
                        moveForward(devices);
                    }
                }
            }
        }
        
    }
}
