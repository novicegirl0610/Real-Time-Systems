﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaskList : MonoBehaviour
{
    protected TaskInterface[] tasks = new TaskInterface[] {
        new RotateTowardsGoalNode(), 
        new LongRoadTravel(), 
        new LeftRoadTravel(), 
        new CrossBridge()
    };

    public TaskInterface[] GetTasks() {
        return this.tasks;
    }
}
