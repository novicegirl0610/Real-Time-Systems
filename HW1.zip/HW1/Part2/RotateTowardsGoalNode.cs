using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class RotateTowardsGoalNode : TaskInterface
{
    public bool alreadyRotated = false;
    public bool turnedTowardsGoal = false;

    private DateTime start;
    public void moveForward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 10f;
    }

    public void moveBackward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = -10f;
    }

    public void slowDown(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 0f;
    }


    public void changeDirection(DeviceRegistry devices, bool isA){
        devices.steeringControl[0] = 1f;
        if (isA) {
                devices.steeringControl[1] = -3;
        } else {
            devices.steeringControl[1] = 3;
        }
    }

    public void overrideSteering(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = 0f;
    }

    public void stop(DeviceRegistry devices){
        devices.brakeControl[0] = 1f;
        devices.brakeControl[1] = Time.fixedDeltaTime;
    }


    
    public void Execute(DeviceRegistry devices) {
        float angle = devices.compass[0];

        if(!this.turnedTowardsGoal){
            start = DateTime.Now;
            if (Math.Abs(angle) > 0.000001 && !this.alreadyRotated){
                devices.steeringControl[0] = 1;
                devices.steeringControl[1] = -1.0f * angle;
                this.alreadyRotated = true;
                this.turnedTowardsGoal = true;
            }
            TimeSpan time = DateTime.Now - start;
            Debug.Log("Rotation Task Total Time: ");
            Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
        }
        
    }
}
