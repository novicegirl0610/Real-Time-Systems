using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class LeftRoadTravel : TaskInterface
{
    public bool reachedBridge = false;
    public bool tookLeftTurn = false;
    public bool tookRightTurn = false;
    public bool infrontOfBridge = false;
    private DateTime start;
    public void moveForward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 10f;
    }

    public void moveBackward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = -10f;
    }

    public void slowDown(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 0f;
    }
    public void turnLeft(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = -90.0f;
    }

    public void turnRight(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = 90.0f;
    }

    public void overrideSteering(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = 0f;
    }

    public void stop(DeviceRegistry devices){
        devices.brakeControl[0] = 1f;
        devices.brakeControl[1] = Time.fixedDeltaTime;
    }


    public bool isRoad(DeviceRegistry devices){
        
        for (int i = 4; i < 7; i++){
            //Road pixels [120, 120, 120]
            if (devices.pixels[i, 7, 0] != 120 || devices.pixels[i, 7, 1] != 120 || devices.pixels[i, 7, 2] != 120){
                return false;
            }
        }
        return true;
    }

    
    public void Execute(DeviceRegistry devices) {

        float angle = devices.compass[0];
        if(Math.Abs(angle + 90.0f) <= 0.01 && !this.tookLeftTurn){
            start = DateTime.Now;
            this.tookLeftTurn = true;
        }

        if(this.tookLeftTurn && !this.infrontOfBridge){
            if(isRoad(devices) && !this.reachedBridge){
                moveForward(devices);
            }
            else if(!this.reachedBridge){
                slowDown(devices);
                stop(devices);
                this.reachedBridge = true;
            }
            else if(!this.tookRightTurn){
                turnRight(devices);
                this.tookRightTurn = true;
            }
            else if(!this.infrontOfBridge){
                overrideSteering(devices);
                this.infrontOfBridge = true;
                TimeSpan time = DateTime.Now - start;
                Debug.Log("Left Road Execution Time");
                Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
            }
        }
        
        
    }
}
