using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class LongRoadTravel : TaskInterface
{
    public bool stoppedVehicle = false;

    public bool turnedVehicle = false;
    public bool alreadyRotatedTowardsGoal = false;

    public bool steeringControlled = false;

    public bool firstTimeMoveForward = false;
    private DateTime start;
    public void moveForward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 10f;
    }

    public void moveBackward(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = -10f;
    }

    public void slowDown(DeviceRegistry devices){
        devices.speedControl[0] = 1f;
        devices.speedControl[1] = 0f;
    }

    public void turnLeft(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = -90.0f;
    }

    public void overrideSteering(DeviceRegistry devices){
        devices.steeringControl[0] = 1f;
        devices.steeringControl[1] = 0f;
    }

    public void stop(DeviceRegistry devices){
        devices.brakeControl[0] = 1f;
        devices.brakeControl[1] = Time.fixedDeltaTime;
    }

    public bool isRoad(DeviceRegistry devices){
        
        for (int i = 4; i < 7; i++){
            //Road pixels [120, 120, 120]
            if (devices.pixels[i, 7, 0] != 120 || devices.pixels[i, 7, 1] != 120 || devices.pixels[i, 7, 2] != 120){
                return false;
            }
        }
        return true;
    }

    
    public void Execute(DeviceRegistry devices) {
        
        float angle = devices.compass[0];
        if (Math.Abs(angle) <= 0.000001 && !this.alreadyRotatedTowardsGoal){
            start = DateTime.Now; 
            overrideSteering(devices);
            this.alreadyRotatedTowardsGoal = true;
        }
        if (this.alreadyRotatedTowardsGoal && !this.steeringControlled){
            if(isRoad(devices) && !this.stoppedVehicle){
                if(!this.firstTimeMoveForward){
                    moveForward(devices);
                }
                this.firstTimeMoveForward = true;
            }
            else if(!this.stoppedVehicle){
                slowDown(devices);
                stop(devices);
                this.stoppedVehicle = true;
            }
            else if(!this.turnedVehicle && !this.steeringControlled){
                //Debug.Log("Long Road: Turning Left");
                turnLeft(devices);
                this.turnedVehicle = true;
            }
            else if (!this.steeringControlled){
                //Debug.Log("Long Road: Overriding Steering");
                overrideSteering(devices);
                this.steeringControlled = true;
                TimeSpan time = DateTime.Now - start;
                Debug.Log("Long Road Total Execution");
                Debug.Log(String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(4, '0')));
            }
        }
        

    }
}
